

*** FLOCKING SIMULATOR READ ME***

To run the application:

1. COMPILE all .java files in the first level:
	(***WARNING: Do NOT include anything from "Tests" when running the application***). 
	
	Only these files should be compiled to run:
	- Boid.java
	- BoidPanel.java
	- Coordinate.java
	- MainFrame.java
	- MenuPanel.java
	- Vector2D.java
	- WorldSimulation.java
	

2: RUN MainFrame.java with no external inputs: "java MainFrame"
