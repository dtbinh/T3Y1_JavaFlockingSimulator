

*** FLOCKING SIMULATOR READ ME***

To run the application:

1. COMPILE all .java files in directive "FlockingSimulator":
***WARNING: Do NOT include anything from other directives when compiling/running the application*** 
	
	Only these files should be compiled:
	- Boid.java
	- BoidPanel.java
	- Coordinate.java
	- MainFrame.java
	- MenuPanel.java
	- Vector2D.java
	- WorldSimulation.java
	

2: RUN MainFrame.java with no external inputs: "java MainFrame"
